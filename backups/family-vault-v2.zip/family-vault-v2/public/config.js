export const config = {
  firebase: { apiKey:'YOUR_API_KEY', authDomain:'YOUR_PROJECT.firebaseapp.com', projectId:'YOUR_PROJECT', appId:'YOUR_APP_ID' },
  apiUrl:'YOUR_NEW_APPS_SCRIPT_EXEC_URL',
  currency:'USD', idleMinutes:5, maxDocumentBytes:3*1024*1024
};
