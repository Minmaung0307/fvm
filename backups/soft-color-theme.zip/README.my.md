# Soft Color Theme ထည့်နည်း

၁။ `soft-color-theme.css` ကို project ရဲ့ `public` folder ထဲထည့်ပါ။
၂။ `public/index.html` ထဲ `</head>` မတိုင်မီ အောက်ကတစ်ကြောင်းထည့်ပါ။

```html
<link rel="stylesheet" href="/soft-color-theme.css">
```

၃။ `public/sw.js` ထဲ CACHE နာမည်ကို အသစ်ပြောင်းပါ။ ဥပမာ `family-vault-personal-shell-theme-1`။ SHELL array ထဲ `'/soft-color-theme.css'` ထည့်ပါ။
၄။ Save ပြီး deploy လုပ်ပါ။

```bash
npx firebase-tools deploy --only hosting
```

၅။ Browser ကို reload လုပ်ပါ။ မပြောင်းသေးလျှင် site tabs/PWA အားလုံးပိတ်ပြီး ပြန်ဖွင့်ပါ။

အစားထိုးနည်းအဖြစ် CSS ဖိုင်ထဲက code အားလုံးကို လက်ရှိ `public/style.css` အောက်ဆုံးမှာ paste လုပ်လည်းရသည်။ ထိုနည်းသုံးလျှင် index.html နှင့် sw.js ပြင်ရန်မလိုပါ။ မူလ CSS ကို မဖျက်ပါနှင့်။
