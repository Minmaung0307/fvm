import test from 'node:test';
import assert from 'node:assert/strict';
import {addExamples} from '../public/samples.js';
import {initialData,allEvents} from '../public/vault.js';
test('three labeled examples are idempotent and never create reminders',()=>{const first=addExamples(initialData(),'2026-09-18');assert.equal(first.records.length,3);assert.ok(first.records.every(r=>r.isExample));assert.equal(allEvents(first).length,0);assert.equal(addExamples(first,'2026-09-18').records.length,3);assert.ok(first.settings.examplesAdded);assert.equal(first.records[0].group,'အိမ်');assert.equal(first.records[0].category,'Internet');});
test('editing an example into a real bill makes its due date eligible',()=>{const value=addExamples(initialData(),'2026-09-18');value.records[0].isExample=false;assert.equal(allEvents(value).length,1);assert.equal(allEvents(value)[0].kind,'due');});
