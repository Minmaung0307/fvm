# Family Vault v2.1 — UI update လုပ်ရန်

ဒီ update သည် လက်ရှိ login / Gmail / Drive / Sheets backend ကိုဆက်သုံးသည်။ Accounts, bills, docs, backups နှင့် encryption format မပြောင်းပါ။ လက်ရှိ Apps Script ကို overwrite/deploy ပြန်လုပ်စရာမလိုပါ။

## Update အဆင့်များ

1. လက်ရှိ app မှ Encrypted backup ယူပါ။ မိမိ public/config.js ကိုသီးခြား backup သိမ်းထားပါ။
2. `family-vault-v2.1-update.zip` ကိုဖြည်ပါ။ ZIP ထဲ `public/` နှင့် `firebase.json` ရှိသည်။
3. ZIP ၏ `public/` ထဲကဖိုင်များကို မိမိ project ၏ **ရှိပြီးသား public/ ထဲသို့ copy/overwrite** လုပ်ပါ။ Public folder ကိုမဖျက်ပါနှင့်။ ZIP ထဲ `config.js` မထည့်ထားသဖြင့် သင့်လက်ရှိ config.js ကိုဆက်ထားရမည်။
4. Root `firebase.json` ကို ZIP ထဲက version ဖြင့် update လုပ်ပါ။ လက်ရှိ configuration တွင် custom hosting targets/site IDs ရှိလျှင် ၎င်းတို့ကိုဆက်ထိန်းပြီး security headers ကိုသာကူးပါ။ ပုံမှန် single-site project သည် ဖိုင်အစားထိုးနိုင်သည်။
5. မိမိ project root Terminal မှ run ပါ။

```sh
npx firebase-tools deploy --only hosting
```

6. App tabs အားလုံးပိတ်၍ပြန်ဖွင့်ပါ။ PWA သည် version အသစ်ရောက်ရန် tabs အဟောင်းပိတ်ရမည်။ Browser တွင် Cmd + Shift + R ဖြင့် hard reload လုပ်နိုင်သည်။
7. Google login/unlock ပြန်လုပ်ပါ။ မသိမ်းရသေးသော form edits များသည် refresh/lock လုပ်လျှင်ပျောက်မည်။ သိမ်းပြီးသား Drive data ကိုမဖျက်ပါ။

## အသစ်ပါဝင်သည့်အရာများ

- ပိုသပ်ရပ်သော dashboard၊ cards၊ form sections၊ sticky header။ External web fonts မသုံး၍ Google Fonts CSP errors မလိုတော့ပါ။
- Field ဘေး ? ကို desktop hover/keyboard focus သို့ phone/tablet tap ဖြင့် field-specific help ကြည့်နိုင်သည်။ အပေါ် “အသုံးပြုနည်း” မှလမ်းညွှန်အပြည့်ဖတ်နိုင်သည်။
- Account နှင့် Bill အသစ်သီးခြားခလုတ်။ Account ရွေးလျှင်မလိုသော bill fields ဖျောက်၊ Bill ရွေးလျှင် amount/cycle/due date ကိုရှေ့ထားသည်။ Optional login/date details ကိုဖြန့်ကြည့်နိုင်သည်။
- Phone တွင် bottom navigation နှင့်ချုံ့ထားသော filters; tablet တွင်နှစ်ကော်လံ၊ desktop တွင်သုံးကော်လံ။ Dialog fields သည် screen ကျဉ်းလျှင်တစ်ကော်လံဖြစ်သည်။
- နမူနာ၃ခု: အိမ် Internet bill၊ ကားအာမခံ၊ ကိုယ်ပိုင် Email account။ အစစ် password မပါပါ။ နမူနာတွင် label ထည့်ထားသည်။ Real bill estimate/alert မှဖယ်ထားသည်။
- Vault အလွတ်တွင်နမူနာများကို encrypted save ဖြင့်တစ်ကြိမ် auto-add လုပ်သည်။ Data ရှိပြီးသား vault တွင် “နမူနာ ၃ ခု ထည့်ရန်” ကိုနှိပ်နိုင်သည်။ ထပ်နှိပ်လျှင်ရှိပြီးသားနမူနာကို duplicate မလုပ်ပါ။
- နမူနာကို Edit လုပ်ပြီး Save လုပ်လျှင်တကယ့် record ပြောင်းသည်။ ကိုယ့် due date/amount/provider ကိုသေချာပြင်ပါ။ မလိုလျှင် Delete လုပ်ပါ။
- Loading indicator နှင့်keyboard/touch-friendly focus states။

## Group / Category / Tags ကွာခြားချက်

| Record | Group — ကိုယ်တိုင်စုစည်းရာ | Category — အမျိုးအစား | Tags — ရှာဖွေ keyword |
|---|---|---|---|
| အိမ် Internet bill | အိမ် | Internet | home, internet |
| ကားအာမခံ | ငွေရေးကြေးရေး | Insurance | car, policy |
| ကိုယ်ပိုင် Email | မိသားစု | Account | email, personal |

Group ကို Groups & settings မှလိုသလိုသတ်မှတ်နိုင်သည်။ Category သည်ပုံမှန် record အမျိုးအစားစာရင်းဖြစ်သည်။ Group တစ်ခုထဲ category အမျိုးမျိုးထားနိုင်သည်။ Document များကိုလည်းတူညီသော group/tag ဖြင့်စုစည်းနိုင်သည်။ Document ၏ file type ကိုဖိုင်အမျိုးအစားမှသိသည်။

## Gmail / Drive

မိသားစုဝင်တစ်ယောက်ချင်းသည် သူ့ Gmail နဲ့ဝင်နိုင်သည်။ Apps Script FAMILY_EMAILS နှင့် OAuth Testing mode ၏ Test users ထဲ Gmail ထည့်ထားရမည်။ Basic login ဝင်ရုံဖြင့်မလုံလောက်ဘဲ Drive consent ကိုလည်းခွင့်ပြုရမည်။

Records/payment/doc metadata သည် login ဝင်သူ၏ Drive ပိုင် encrypted Google Sheet၊ doc bytes သည်ထိုသူ၏ private folder ထဲ encrypted files အဖြစ်သိမ်းသည်။ အခြား family member နဲ့အလိုအလျောက် share မလုပ်ပါ။ Groups & settings → Private Drive folder / Encrypted Google Sheet လင့်ခ်မှသေချာစစ်နိုင်သည်။ Email reminders opt-in လုပ်ထားလျှင် script server တွင်ရက်စွဲ/email metadata ရှိသည်။

## Lock ဘာလုပ်သလဲ

Lock နှိပ်လျှင် decrypted records, documents metadata, encryption keys နှင့် edit forms ကို memory/view မှရှင်းသည်။ Google login session ဆက်ရှိသည်။ Vault passphrase ဖြင့်ပြန်ဖွင့်ရမည်။ Google Drive ထဲကသိမ်းပြီးသား data မဖျက်ပါ။ မသိမ်းရသေးသော form edits ပျောက်မည်။

Idle ၅ မိနစ် သို့ app/tab ကို background သို့ပြောင်းလျှင် auto-lock ဖြစ်သည်။ Sign out သည် vault lock အပြင် Google login session မှပါထွက်ခြင်းဖြစ်သည်။ Download ပြီးသား plaintext document files ကို Lock က device မှမဖျက်ပေးပါ။

## Verification

Automated checks ၁၄ ခုအောင်မြင်ထားသည်။ Encryption/auth/ownership/revision checks နှင့်နမူနာများ reminder မထွက်ခြင်း၊ duplicate မဖြစ်ခြင်းကိုစစ်ထားသည်။ Responsive CSS သည် mobile/tablet/desktop breakpoints အတွက်ရေးထားသည်။

Browser preview ကို tool ၏ URL security policy ကပိတ်ထားသောကြောင့် real-device / browser visual verification ကိုမပြုလုပ်နိုင်ခဲ့ပါ။ Deployment ပြီးနောက် ဖုန်း၊ iPad/tablet နှင့်desktop တို့တွင် nav, dialogs, filters နှင့်help ကိုတစ်ကြိမ်စမ်းပါ။ Cloud login သည်မိမိလုပ်ထားသော backend/OAuth configuration ကိုဆက်သုံးသည်။
