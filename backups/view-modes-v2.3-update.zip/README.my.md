# Normal / Compact Grid / List update

လက်ရှိ Family Vault v2.2 frontend အတွက် အပို update ဖြစ်သည်။ `config.js`၊ Apps Script နဲ့ မူလ `public` folder ကို မဖျက်ပါနှင့်။

## ထည့်နည်း

၁။ ZIP ထဲက ဖိုင် ၃ ခုကို မိမိ project ရဲ့ `public` folder ထဲထည့်ပါ။

- `view-modes.js`
- `view-modes-core.js`
- `view-modes.css`

၂။ ယခင် `view-switcher.js` / `view-switcher.css` ကို ထည့်ထားလျှင် `index.html` ထဲက ယင်းဖိုင်နှစ်ခု၏ `<script>` / `<link>` စာကြောင်းကို ဖယ်ပါ။ ဖိုင်တွေကို မဖျက်လည်းရသော်လည်း မချိတ်ထားတာ ပိုရှင်းပါတယ်။

၃။ `public/index.html` ထဲ `</head>` မတိုင်မီ ထည့်ပါ။

```html
<link rel="stylesheet" href="/view-modes.css">
```

၄။ `</body>` မတိုင်မီ ထည့်ပါ။

```html
<script type="module" src="/view-modes.js"></script>
```

၅။ `public/sw.js` ထဲ CACHE အမည်ကို အသစ်ပြောင်းပါ။ ဥပမာ:

```js
const CACHE='family-vault-personal-shell-v2-3';
```

SHELL array ထဲ အောက်ကဖိုင်သုံးခု ထည့်ပါ။ ရှိပြီးသားဖိုင်စာရင်းကို မဖျက်ပါနှင့်။

```js
'/view-modes.js','/view-modes-core.js','/view-modes.css'
```

၆။ Deploy လုပ်ပါ။

```bash
npx firebase-tools deploy --only hosting
```

Browser/PWA ကို reload လုပ်ပါ။ မပြောင်းသေးလျှင် tabs/PWA အားလုံးပိတ်ပြီး ပြန်ဖွင့်ပါ။

## အသုံးပြုပုံ

- **Normal** — လက်ရှိ card အကြီးပုံစံအတိုင်း။
- **Grid** — အကွက်သေးသေးများများ။ Card ကိုနှိပ်၊ Enter သို့ Space နှိပ်လျှင် အပြည့်ဖြန့်ပြမည်။ ပြန်နှိပ်လျှင် ပိတ်မည်။
- **List** — record/document တစ်ကြောင်းစီ။ Row ကိုနှိပ်၊ Enter သို့ Space နှိပ်လျှင် card အပြည့်ဖြန့်ပြမည်။

Edit/Delete/Download စသော ခလုတ်ကိုနှိပ်ခြင်းက card ဖွင့်/ပိတ်ခြင်း မလုပ်ဘဲ မူလလုပ်ဆောင်ချက်ကိုသာ လုပ်ပါသည်။ ရွေးထားသော view ကို browser တွင်သာ မှတ်ထားပြီး Vault data/password/token မသိမ်းပါ။

Category နှင့် Group badge အရောင်သည် အမည်ကိုတွက်ပြီး သတ်မှတ်တာဖြစ်လို့ အမည်တူရင် အမြဲတူညီသောအရောင်ရသည်။ အသစ်ထည့်သော Group/Category အတွက် code ထပ်ပြင်ရန်မလိုပါ။ အရောင် ၁၀ မျိုးစီရှိသောကြောင့် အမည်အရမ်းများလျှင် အရောင်တူနိုင်သော်လည်း badge စာသားက ဆက်ပြထားပါသည်။ Documents တွင် Category field မရှိသောကြောင့် Group နှင့် Status အရောင်ကို ပြပါသည်။

Payment history မရှိချိန် `+ Account အသစ်` မပြတော့ဘဲ Bill ထဲက `Record payment` ကိုသုံးရန် လမ်းညွှန်ပြပါသည်။ ယင်း `+ Account` က မိသားစုဝင်ထည့်ရန် မဟုတ်ပါ။
