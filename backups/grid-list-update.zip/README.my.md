# Grid / List ထည့်နည်း
လက်ရှိ v2.2 frontend အတွက်ဖြစ်သည်။ config.js၊ backend နဲ့ မူလ public folder ကို မဖျက်ပါနှင့်။

၁။ view-switcher.js နဲ့ view-switcher.css ဖိုင်နှစ်ခုကို မိမိ project public folder ထဲ ထည့်ပါ။
၂။ public/index.html မှာ </head> မတိုင်မီ ဒီတစ်ကြောင်းထည့်ပါ။

```html
<link rel="stylesheet" href="/view-switcher.css">
```

၃။ </body> မတိုင်မီ ဒီတစ်ကြောင်းထည့်ပါ။

```html
<script type="module" src="/view-switcher.js"></script>
```

၄။ public/sw.js ထဲ CACHE နာမည်ကို မူလနာမည်အစား family-vault-personal-shell-v2-2-layout-1 ပြောင်းပါ။ SHELL array ထဲ '/view-switcher.js','/view-switcher.css' ကို ထည့်ပါ။ မူလဖိုင်စာရင်းတွေကို ဆက်ထားပါ။
၅။ Save ပြီး Terminal မှာ npx firebase-tools deploy --only hosting လုပ်ပါ။ Browser ကို reload လုပ်ပါ။ PWA မပြောင်းသေးလျှင် app/browser tabs အားလုံးပိတ်ပြီး ပြန်ဖွင့်ပါ။

Accounts & bills နဲ့ Documents မှာ Grid / List ခလုတ်ပေါ်မည်။ လက်ရှိ card ထဲက Edit, Delete, Archive, Payment ခလုတ်တွေ ဆက်အလုပ်လုပ်မည်။ Layout ရွေးချယ်မှုကိုသာ browser တွင်မှတ်ထားသည်။ Vault data၊ password နဲ့ token မသိမ်းပါ။

Calendar/Payments/Settings တွင် layout ခလုတ်မပေါ်ပါ။ ဤ update သည် admin/public registration ကို မထည့်သေးပါ။
