# Family Vault v3 — Public registration + Admin

ဤ project ကို folder အသစ်တွင် ဖွင့်ပြီး setup လုပ်ပါ။ မူလ v2 project folder ကို မဖျက်ပါနှင့်။ မူလ public folder ကို Replace All မလုပ်ပါနှင့်။ ဤ version သည် HTML ထဲ စာကြောင်းအနည်းငယ်ထည့်ခြင်းထက် backend အသစ် deploy လုပ်ရန် လိုအပ်ပါသည်။ သင့် behalf ဖြင့် deploy မလုပ်ရသေးပါ။

## ပါဝင်သော features

- Verified Google login၊ Terms/Privacy consent version မှတ်ခြင်း။
- Approval / Invite only / Open registration — Admin က UI မှ ပြောင်းနိုင်သည်။
- Admin သီးခြား `/admin.html`၊ Users ၅၀ ဦးစီ pagination၊ Gmail အတိအကျရှာခြင်း၊ approve/suspend/pending၊ တစ်ကြိမ် ၂၅ ဦးအထိ bulk approve/suspend။
- Email တစ်ခုအတွက်သာ တစ်ကြိမ်သုံး invite၊ ၁–၃၀ ရက် expiry၊ revoke၊ server တွင် invite token hash သာသိမ်းခြင်း။ Invite များကို အလိုအလျောက် email မပို့ပါ။ Admin က link ကို ကိုယ်တိုင်ပို့ရသည်။
- Admin လုပ်ဆောင်မှု audit၊ request ၆၀/မိနစ်/user၊ registration limit (default ၅၀၀)၊ optional App Check။
- ကိုယ်ပိုင် Google Drive folder/Sheet၊ encrypted records/documents၊ client-side AES-GCM/PBKDF2၊ passphrase change၊ encrypted backup။
- Group/category add/rename/remove၊ record add/edit/delete/duplicate/archive၊ search/filter/sort၊ payment history၊ calendar၊ Grid/List၊ responsive PWA၊ Burmese hover/tap help၊ sample records။
- Manual Lock၊ idle/tab-hidden Lock၊ optional generic daily email reminders၊ account close (Drive ဖိုင်တွေမဖျက်)။

## စနစ်ပြောင်းသွားသည့်အချက်

Frontend: Firebase Hosting + Authentication။
Admin/membership metadata: Firestore (server-only access)။
Backend: Cloud Functions for Firebase (Node 22)။
Vault data: မိမိ Drive/Sheets ထဲ ciphertext အဖြစ် ဆက်သိမ်းသည်။

v3 သည် Apps Script ကို အဓိက backend အဖြစ် မသုံးတော့ပါ။ လူ ၂၀၀ အတွက် shared Apps Script lock ကိုဖယ်ပြီး user တစ်ယောက်စီ lock ထားပါသည်။ မိမိ user ၏ devices နှစ်ခု တစ်ပြိုင်နက် save လုပ်လျှင် တစ်ခုက retry/Refresh လုပ်ရန် message ရမည်။ လူ ၂၀၀ အတွက် production load test မလုပ်ရသေးပါ။ အရေအတွက်သည် capacity အာမခံချက် မဟုတ်ပါ။

Firestore တွင် Google login email/name/UID၊ status၊ consent၊ login time၊ invite hash/audit၊ server-side folder/Sheet IDs ကို ဖတ်နိုင်သော metadata အဖြစ် သိမ်းပါသည်။ Vault password၊ account number၊ record memo၊ document name/contents၊ master passphrase၊ Google token ကို မသိမ်းပါ။ Email reminder ဖွင့်ထားလျှင် reminder dates/kinds/email ကို server တွင် သိမ်းပါသည်။

## ၁။ မူလ data ကို backup လုပ်ပါ

၁။ မူလ app မှ Encrypted backup ကို download လုပ်ပါ။ Passphrase ကို သီးခြား လုံခြုံစွာ မှတ်ထားပါ။
၂။ မူလ `public/config.js`၊ Firebase project ID၊ Google provider/OAuth client settings ကို copy သီးခြားသိမ်းပါ။
၃။ ZIP ကို extract လုပ်ပြီး `family-vault-v3` folder ကို VS Code ဖြင့်ဖွင့်ပါ။ မူလ project ကို မဖျက်ပါနှင့်။

## ၂။ Firebase Console ပြင်ဆင်ပါ

၁။ Firebase Console → `fvm-26` project ကိုရွေးပါ။
၂။ Cloud Functions deploy အတွက် Blaze plan (billing account ချိတ်ခြင်း) လိုပါသည်။ Billing → Budget alerts သတ်မှတ်ပါ။ Budget alert သည် အလိုအလျောက် အသုံးစရိတ်ဖြတ်တောက်ပေးခြင်း မဟုတ်ပါ။
၃။ Build → Firestore Database → Create database → default database၊ location ရွေးပါ။ သင့် project အတွက် location မရွေးရသေးလျှင် functions `us-central1` နှင့် နီးစပ်ရာကို ရွေးပါ။ Production mode ရွေးပါ။
၄။ Authentication → Sign-in method → Google ကို Enabled ထားပါ။ မူလ provider/OAuth client ကို ဆက်သုံးပါ။
၅။ Authentication → Settings → Authorized domains မှာ `fvm-26.web.app`၊ `fvm-26.firebaseapp.com`၊ သင့် custom domain ကို ထည့်ပါ။ Domain name သာဖြစ်ရမည်။ `https://`၊ path၊ port မထည့်ပါနှင့်။
၆။ Google Cloud Console တွင် Drive API နှင့် Sheets API Enabled ဖြစ်ကြောင်း စစ်ပါ။

Cloud Functions/Firebase Hosting official setup: https://firebase.google.com/docs/functions/get-started နှင့် https://firebase.google.com/docs/hosting/functions

## ၃။ Public config

`public/config.js` တွင် သင့်ယခင်ပြထားသော fvm-26 Web config ကို ဖြည့်ထားသည်။ မူလ app မှ config နှင့် တိုက်စစ်ပါ။ Firebase Console → Project settings → Your apps → Web app မှ ယူနိုင်သည်။

```js
apiUrl:'/api'
```

v3 တွင် API URL သည် အပေါ်က `/api` ဖြစ်သည်။ Apps Script `/exec` URL မထည့်တော့ပါ။ Firebase Hosting rewrite က Cloud Function သို့ ချိတ်ပေးသည်။

Firebase Web API key သည် browser configuration ဖြစ်သည်။ Owner/admin email list၊ Resend API key၊ service-account credentials ကို public config ထဲ မထည့်ပါနှင့်။ Service-account JSON download လုပ်ပြီး project ထဲထည့်ရန် မလိုပါ။ Cloud Functions က default server identity ကိုသုံးသည်။

`.firebaserc` သည် fvm-26 ကိုရွေးထားသည်။ အခြား project သုံးလိုလျှင် ဤဖိုင်နှင့် public config နှစ်ခုလုံးကို ပြင်ပါ။ မူလ encrypted data ကိုဆက်ဖတ်လိုလျှင် မူလ Firebase project၊ မူလ Firebase UID နှင့် မူလ Google OAuth client ကို ဆက်သုံးပါ။ Project/OAuth client ပြောင်းလျှင် drive.file visibility နှင့် UID မတူသဖြင့် မူလဖိုင်တွေ မတွေ့နိုင်ပါ။

## ၄။ Owner/admin configuration

`functions/.env.example` ကို copy လုပ်ပြီး **`functions/.env.fvm-26`** ဟု အမည်ပေးပါ။ ဖိုင်မှာ တကယ့် `.` နဲ့ စသည်။

```ini
ADMIN_EMAILS=minmaung0307@gmail.com
SITE_URL=https://fvm-26.web.app
REGISTRATION_MODE=approval
MAX_REGISTRATIONS=500
APP_CHECK_REQUIRED=false
EMAIL_ENABLED=false
EMAIL_FROM=Family Vault <noreply@YOUR_VERIFIED_EMAIL_DOMAIN>
```

- ADMIN_EMAILS သည် သင့် admin Gmail ဖြစ်သည်။ Admin ထပ်လိုလျှင် comma ဖြင့်ခွဲထည့်ပြီး functions redeploy လုပ်ပါ။ UI မှ admin အဖြစ် အခြားသူကို အလိုအလျောက် မမြှင့်နိုင်ပါ။ Server သည် verified Google identity ကိုသာ လက်ခံသည်။
- SITE_URL ကို HTTPS app URL အပြည့်ဖြည့်ပါ။ Custom domain အလုပ်လုပ်ပြီးမှ ပြောင်းပါ။
- REGISTRATION_MODE က first-run default သာဖြစ်သည်။ Admin Dashboard မှ mode ပြောင်းပြီးနောက် Firestore setting က ဦးစားပေးဖြစ်သည်။
- MAX_REGISTRATIONS သည် စာရင်းသွင်းဖူးသူစုစုပေါင်း limit ဖြစ်သည်။ Pending/Closed ပါဝင်သည်။ Account ပိတ်လျှင် slot အလိုအလျောက် ပြန်မလွတ်ပါ။ ပြည့်လျှင် limit တိုးပြီး functions redeploy လုပ်ပါ။ Owner က limit ပြည့်ချိန်တွင်လည်း ဝင်နိုင်သည်။
- Email မသုံးသေးလျှင် EMAIL_ENABLED=false ဆက်ထားပါ။

ဤ env ဖိုင်ကို `.gitignore` ဖြင့် Git ထဲမတင်ပါ။ `.env.example` သည် template သာဖြစ်သည်။

## ၅။ Install / Deploy

VS Code Terminal သည် `family-vault-v3` folder ထဲတွင် ဖြစ်ရမည်။ Node.js 22 ထည့်ထားပါ။ ဤ command တွေကို တစ်ခုစီ run ပါ။

```bash
npm install
npm --prefix functions install
npx firebase-tools login
npx firebase-tools use fvm-26
```

Optional email function အတွက် secret ကို ဖန်တီးထားပါ။ Email မသုံးသေးလျှင် value ကို `disabled` ဟု ထည့်နိုင်ပါသည်။ Code က EMAIL_ENABLED=false ဖြစ်ချိန် mail မပို့ပါ။

```bash
npx firebase-tools functions:secrets:set MAIL_API_KEY
```

ပြီးလျှင် tests run ပါ။

```bash
npm test
```

### မူလ app မှ upgrade လုပ်သူများအတွက် Maintenance

မူလ app users မသုံးနေချိန် upgrade လုပ်ပါ။ **v2 Apps Script နှင့် v3 Cloud Functions ကို တစ်ချိန်တည်း write လုပ်ခွင့်မထားပါနှင့်။** နှစ်ခု၏ lock များသည် အပြန်အလှန် မချိတ်ထားပါ။

- Apps Script → Deploy → Manage deployments → မူလ vault web-app deployment ကို Archive လုပ်ပါ။
- Apps Script → Triggers → `sendDailyReminders` trigger ကိုဖယ်ပါ (duplicate email မပို့ရန်)။
- မူလ Drive folder/Sheet/documents ကို မဖျက်ပါနှင့်။

ယခု deploy လုပ်ပါ။

```bash
npx firebase-tools deploy --only functions,firestore,hosting
```

Google API enable/IAM permission တောင်းလျှင် Firebase project Owner account ဖြင့် ဆက်လုပ်ပါ။ functions secret access error ရှိလျှင် deploy command ပြထားသော IAM setup ကိုစစ်ပါ။ Deploy သည် Blaze billable services ကိုဖန်တီးသည်။ ဤ ZIP ဖန်တီးထားခြင်းက သင့် project တွင် deploy ပြီးပြီဟု မဆိုလိုပါ။

## ၆။ ပထမဆုံး Admin ဝင်နည်း

၁။ `https://fvm-26.web.app/admin.html` ကိုဖွင့်ပါ။
၂။ ADMIN_EMAILS ထဲရှိ သင့် Gmail ဖြင့် ဝင်ပါ။
၃။ Registration mode ကို **Approval** အရင်ထားပြီး စမ်းပါ။
၄။ သင့် Vault ကိုသုံးလိုလျှင် `/` သို့သွားပြီး Google login ထပ်လုပ်ပါ။ Auth သည် in-memory ဖြစ်သောကြောင့် page ပြောင်း/refresh လုပ်လျှင် ပြန်ဝင်ရနိုင်ပါသည်။
၅။ Privacy/Terms checkbox ကိုရွေးပြီး ဝင်ပါ။ Owner သည် active အဖြစ် အလိုအလျောက် register ဖြစ်သည်။
၆။ မူလ vault ရှိသူက မူလ passphrase ဖြင့်ဖွင့်ပါ။ မူလဖိုင်များကို app marker `family-vault-v2` ဖြင့်ဆက်ရှာသည်။ မူလ data မမြင်ရလျှင် reset/new passphrase မလုပ်မီ project/UID/OAuth client/Drive file ownership ကိုစစ်ပါ။

## ၇။ Users ခွင့်ပြုပေးနည်း

Approval mode တွင် သုံးချင်သူက app link ဖွင့်၊ Privacy/Terms သဘောတူ၊ Google login လုပ်ပါ။ Pending screen ပေါ်မည်။
Admin → Users → Gmail အတိအကျရှာ → Approve လုပ်ပါ။ User က **ခွင့်ပြုချက် ပြန်စစ်ရန်** နှိပ်ပြီး ကိုယ်ပိုင် passphrase သတ်မှတ်နိုင်ပါသည်။ `FAMILY_EMAILS` ထဲ လက်ဖြင့်ထည့်ရန် မလိုတော့ပါ။

Suspend သည် server requests အသစ်များကို ပိတ်သည်။ ဖွင့်ထားပြီးသော Vault memory/device download ကို အဝေးမှ အလိုအလျောက် ဖျက်နိုင်ခြင်း မရှိပါ။ နောက် backend request တွင် suspended ဖြစ်နေသည်ကို သိလျှင် UI က Lock လုပ်သည်။ Idle/tab-hidden ဖြစ်လျှင်လည်း Lock လုပ်သည်။

Open mode သည် verified Google users အသစ်များကို active ဖြစ်စေသည်။ ယခင် Pending/Suspended ကို အလိုအလျောက် Approve မလုပ်ပါ။

Invite only mode တွင် Gmail-specific invite link ရှိမှ account အသစ် register လုပ်နိုင်သည်။ ရှိပြီးသား Active users ကို ပိတ်ခြင်းမဟုတ်ပါ။

## ၈။ Invite ဖိတ်ကြားနည်း

Admin → Invite → Gmail + expiry days ဖြည့် → Create invite → Copy link → သင်ကိုယ်တိုင်ပို့ပါ။ ဤ app က အလိုအလျောက် email/Slack မပို့ပါ။
လက်ခံသူသည် invite မှာပါသော Google email တစ်ခုတည်းဖြင့် ဝင်ရမည်။ တစ်ကြိမ်သာ သုံးနိုင်သည်။ Revoke လုပ်လျှင် မသုံးရသေးသော link ပျက်မည်။ အသုံးပြုပြီး user ကိုရပ်ချင်လျှင် Users → Suspend လုပ်ပါ။
Invite token ကို URL fragment (#invite=…) ထဲထားသဖြင့် browser က Hosting request URL ထဲ မပို့ပါ။ Link plaintext ကို database ထဲမသိမ်းသဖြင့် refresh ပြီးနောက် မူလ link ပြန်ဖော်၍မရပါ။ လိုလျှင် မူလ invite revoke လုပ်ပြီး အသစ်ဖန်တီးပါ။

## ၉။ Google OAuth ကို အများသုံးရန် ပြင်နည်း

Google Cloud Console → Google Auth Platform:

- Branding: app name၊ support email၊ developer email၊ app homepage၊ privacy URL `/privacy.html`၊ terms URL `/terms.html` ပြင်ပါ။
- Audience: consumer Gmail users အတွက် External ရွေးပါ။
- Development testing: Test users ထဲ စမ်းသပ်သူ Gmail ထည့်ပါ။ App ၏ Admin approval နှင့် Google OAuth Test users သည် မတူပါ။
- Data Access: လက်ရှိ Google provider က တောင်းသော profile/email/openid နှင့် `https://www.googleapis.com/auth/drive.file` ကို တိုက်စစ်ပါ။ Full Drive scope မတောင်းပါနှင့်။
- လူ ၂၀၀ သုံးစေမည်ဆိုလျှင် Testing mode ကိုပဲထားပြီး Test users တိုးခြင်းထက် production publishing setup လုပ်ပါ။ Publish app/production အတွက် Branding၊ authorized domains၊ verification အခြေအနေကို Google console မှ ပြထားသည့်အတိုင်း ဖြည့်ပါ။ Production ပြောင်းရုံဖြင့် verification အားလုံးပြီးသွားသည်ဟု မယူဆပါနှင့်။
- မူလ Firebase Authentication Google provider OAuth client ကို ဆက်သုံးပါ။ Web redirect URI သည် ပုံမှန် `https://fvm-26.firebaseapp.com/__/auth/handler` ဖြစ်သည်။ Console ထဲရှိ မူလတန်ဖိုးကို မလိုအပ်ဘဲ မပြောင်းပါနှင့်။

Official OAuth policy: https://developers.google.com/identity/protocols/oauth2/production-readiness/overview

Public launch မလုပ်မီ `public/privacy.html` နှင့် `public/terms.html` ထဲ YOUR_OPERATOR_NAME၊ YOUR_SUPPORT_EMAIL ဖြည့်ပါ။ Policy စာသားကို သင်တကယ်ပေးသော service/retention အတိုင်း ပြန်စစ်ပြီးမှ ထုတ်ပါ။ Policy ပြောင်းလျှင် functions/policy.js နှင့် public/app.js ထဲ version၊ policy HTML version တို့ကိုတူအောင် ပြောင်းပါ။

## ၁၀။ Email due/overdue reminder ဖွင့်နည်း (optional)

ဤ version တွင် MailApp/Gmail owner quota အစား Resend email API ကိုသုံးသည်။ Provider account၊ verified sender domain နှင့် သင့် provider quota လိုသည်။ လူ ၂၀၀ သည် နေ့စဉ် emails ၂၀၀ အထိဖြစ်နိုင်သောကြောင့် မိမိ plan က ခံနိုင်သည့်ပမာဏကို စစ်ပါ။

၁။ Resend account တွင် မိမိ sender domain verify လုပ်ပါ။ Domain provider တွင် provider ပြသော DNS records ထည့်ပါ။ API key ထုတ်ပါ။
၂။ Terminal:

```bash
npx firebase-tools functions:secrets:set MAIL_API_KEY
```

ဤတစ်ကြိမ်တွင် တကယ့် Resend API key ထည့်ပါ။ Public config/Git ထဲ မထည့်ပါနှင့်။
၃။ `functions/.env.fvm-26` တွင်:

```ini
EMAIL_ENABLED=true
EMAIL_FROM=Family Vault <noreply@your-verified-domain.com>
```

၄။ Redeploy:

```bash
npx firebase-tools deploy --only functions
```

၅။ User က Groups & settings → email reminder ကို အမှန်ခြစ်ပြီး save လုပ်ပါ။

နေ့စဉ် America/New_York မနက် ၈ နာရီတွင် overdue/နောက်၇ရက် count ကိုပို့သည်။ Record name/password/provider မပါပါ။ Closed/Archived/sample records သည် reminders ထဲမပါပါ။ Member Pending/Suspended/Closed ဖြစ်လျှင် scheduled mail မပို့ပါ။ User ပိတ်ထားလျှင် reminders document ကိုဖျက်သည်။

ဒါသည် real-time notification မဟုတ်ပါ။ Email delivery အောင်မြင်မှုသည် quota/provider/network ပေါ်မူတည်သည်။ Failure များကို user-specific sensitive logs မရေးပါ။ Resend dashboard နှင့် Cloud Functions execution status ကို admin ကစစ်နိုင်သည်။ Browser alerts သည် app open/unlocked ချိန်တွင်သာ၊ background push မပါပါ။

## ၁၁။ App Check ဖွင့်ရန် (public launch အတွက်)

၁။ Firebase Console → App Check → Web app register → reCAPTCHA v3 setup လုပ်ပါ။ Site key/secret ကို Google reCAPTCHA console တွင်ယူပါ။ Hosting/custom domains ကိုခွင့်ပြုပါ။
၂။ Site **public** key ကို `public/config.js` ထဲ `appCheckSiteKey` တွင်ဖြည့်ပါ။ Secret key ကို public ဖိုင်ထဲ မထည့်ပါနှင့်။ Firebase console App Check setup တွင်သာဖြည့်ပါ။
၃။ Hosting deploy လုပ်၊ app နှင့် admin Google login နှစ်ခုလုံးအလုပ်လုပ်ကြောင်း အရင်စစ်ပါ။
၄။ ပြီးမှ env `APP_CHECK_REQUIRED=true` ပြောင်းပြီး functions deploy လုပ်ပါ။ Backend က X-Firebase-AppCheck token ကို verify လုပ်သည်။ App Check UI service enforcement ခလုတ်တစ်ခုတည်းဖြင့် custom backend enforcement ဖြစ်သွားခြင်းမဟုတ်ပါ။

App Check setup မလုပ်မီ true လုပ်လျှင် API 403 ဖြစ်မည်။ Troubleshooting အတွက် false ပြန်ပြောင်းပြီး functions redeploy လုပ်နိုင်သည်။ Anonymous malformed calls သည် Firebase token စစ်ချက်ကို ဖြတ်မရပါ။ Per-user rate limit ကိုလည်း ဖယ်မထားပါ။

https://firebase.google.com/docs/app-check/web/recaptcha-provider

## ၁၂။ Squarespace domain ချိတ်နည်း

Firebase Console → Hosting → Add custom domain → ဥပမာ `vault.yourdomain.com` ထည့်ပါ။ Squarespace domains DNS တွင် Firebase ပြသော TXT/အခြား DNS record value များကို တိတိကျကျထည့်ပါ။ Record value ကို နမူနာခန့်မှန်းမသုံးပါနှင့်။ DNS/SSL provisioning ပြီးသည်အထိ စောင့်ပါ။

Firebase Authentication authorized domains နှင့် App Check/reCAPTCHA allowed domains တွင်လည်း ထည့်ပါ။ OAuth Branding authorized domains/domain verification ကို လိုသလိုလုပ်ပါ။ env SITE_URL ကို custom HTTPS URL ပြောင်းပြီး functions redeploy လုပ်ပါ။

https://firebase.google.com/docs/hosting/custom-domain

## ၁၃။ Account close နှင့် data management

User → Groups & settings → App account ပိတ်ရန်။ App access ပိတ်ပြီး reminder metadata ဖျက်သည်။ Drive files မဖျက်ပါ။ ပိတ်ပြီး Google login လုပ်ရုံဖြင့် ပြန် active မဖြစ်ပါ။ Admin UI မှ closed accounts ပြန်ဖွင့်၍မရပါ။

Directory/consent/audit မှတ်တမ်းသည် server ထဲကျန်သည်။ Metadata deletion/export request များအတွက် Operator က verified account ownership ကိုစစ်ပြီး Firebase Console/Admin tooling ဖြင့် handle လုပ်ရန် လိုသည်။ ဤ release တွင် automatic metadata erasure/retention jobs မပါပါ။ Firebase Auth user ကို delete/recreate လုပ်လျှင် UID ပြောင်းပြီး မူလ Vault မတွေ့နိုင်သဖြင့် ပေါ့ပေါ့ဆဆ မလုပ်ပါနှင့်။

## ၁၄။ Verification နှင့် public launch checklist

Local automated tests တွင် encryption/tamper/wrong passphrase၊ registration states/invite/email match၊ admin privilege၊ consent၊ rate limit၊ ownership checks၊ concurrent same-user lease၊ stale revisions၊ UI asset references စစ်ထားသည်။ Cloud API/Firestore transaction tests သည် mocks ဖြစ်သည်။ Real emulator/cloud deployment၊ mobile/tablet screenshot QA နှင့် ၂၀၀-user load test မလုပ်ရသေးပါ။

Live တွင် အောက်ပါအတိုင်း စမ်းပြီးမှ Open mode ပြောင်းပါ:

- Owner Admin ဝင်နိုင်၊ non-admin Admin API/UI အချက်အလက် မရနိုင်။
- အခြား Gmail Pending → Approve → Vault create/save/edit/refresh → တူညီစွာ ပြန်ဖွင့်နိုင်။
- Users နှစ်ယောက် တစ်ယောက် Drive/Sheet ကိုတစ်ယောက် မမြင်နိုင်။
- Suspend လုပ်လျှင် နောက် load/save ပိတ်၊ Approve ပြန်လျှင် ရမည်။
- Invite wrong email၊ expired/revoked/used link မရ၊ correct email ရ။
- Device နှစ်ခု same account edit လျှင် stale save မoverwrite ဖြစ်။
- Document upload/download/delete၊ passphrase change၊ encrypted backup/restore စမ်း။
- ဖုန်း/iPad/desktop တွင် filters၊ Grid/List၊ forms/help/keyboard သပ်ရပ်မှုစစ်။
- Email ဖွင့်ထားသူ/ပိတ်ထားသူ reminders စမ်း။
- Billing budget alerts၊ provider quotas၊ App Check၊ Operator policies စစ်။

Firestore direct browser access ကို rules က အကုန် deny လုပ်သည်။ Admin SDK server access သည် IAM ဖြင့်ဖြစ်သည်။ Project IAM ထဲ မလိုအပ်သော Editor/Owner users မထားပါနှင့်။ Admin webpage ကိုဖုံးထားရုံဖြင့် လုံခြုံခြင်းမဟုတ်ဘဲ server-side checks က အဓိကဖြစ်သည်။

## အကန့်အသတ်

- Vault passphrase recovery key၊ biometric unlock၊ shared family vault၊ background push၊ billing/subscriptions၊ automated metadata erasure မပါသေးပါ။
- Encrypted backup သည် vault metadata/record/payment နှင့် document key ပါသည်။ Document file bytes မပါပါ။ Docs သီးခြား download/Drive backup ထားရန် လိုသည်။
- Google token သက်တမ်းကုန်လျှင် Sign out → Google login ပြန်လုပ်ပါ။ Google refresh token မသိမ်းထားပါ။
- Storage pointer cache ကြောင့် normal requests တွင် Drive ရှာခြင်းလျော့သည်။ Google Drive/Sheets network latency သည် ဆက်ရှိသည်။ Cache IDs 404 ဖြစ်လျှင် Drive Trash restore လုပ်ပြီး ပြန်စစ်ပါ။ Backend သည် error အတွက် မူလ data ကို အလိုအလျောက် reset မလုပ်ပါ။
- Functions maxInstances=4 သည် cost/concurrency ကို ကန့်သတ်ရန် initial setting ဖြစ်သည်။ လက်တွေ့ဝန်ကိုတိုင်းတာပြီး Google API quotas နှင့်အတူ ပြင်ပါ။ Hard billing cap မဟုတ်ပါ။

Source folder `legacy-apps-script` သည် reference/test အတွက်သာဖြစ်သည်။ v3 deployment တွင် မသုံးပါ။ Backend API ၏ source သည် `functions/` ဖြစ်သည်။
