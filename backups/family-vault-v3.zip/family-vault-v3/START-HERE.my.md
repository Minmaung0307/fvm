# ဒီဖိုင်ကနေ စပါ

ဤ version သည် Admin/Public registration အတွက် backend အသစ်ပါသည်။ HTML/CSS ကိုသာ ကူးထည့်ပြီး သုံး၍မရပါ။ မူလ v2 app/data ကို မဖျက်ပါနှင့်။

၁။ ZIP ကို folder အသစ်မှာ extract လုပ်ပြီး VS Code ဖြင့်ဖွင့်ပါ။
၂။ မူလ app မှ Encrypted backup နှင့် မူလ config.js ကို သီးခြားသိမ်းပါ။
၃။ Firebase fvm-26 တွင် Blaze billing နှင့် Firestore default database setup လုပ်ပါ။ Budget alerts သတ်မှတ်ပါ။
၄။ functions/.env.example ကို functions/.env.fvm-26 အဖြစ် copy လုပ်ပါ။ ADMIN_EMAILS မှာ သင့် Gmail ဖြစ်ကြောင်းစစ်ပါ။
၅။ public/config.js မှာ မူလ Firebase config နှင့် တူကြောင်းစစ်ပါ။ apiUrl သည် /api ဖြစ်ရမည်။
၆။ Terminal တွင် တစ်ကြောင်းစီ:

```bash
npm install
npm --prefix functions install
npx firebase-tools login
npx firebase-tools use fvm-26
npx firebase-tools functions:secrets:set MAIL_API_KEY
npm test
```

Email မသုံးသေးလျှင် secret value ကို disabled ဟုထည့်ပါ။ EMAIL_ENABLED=false ဆက်ထားပါ။

၇။ မူလ v2 Apps Script web-app deployments ကို archive လုပ်ပြီး old reminder trigger ကိုဖယ်ပါ။ Data ဖိုင်တွေ မဖျက်ပါနှင့်။ v2 နှင့် v3 backend နှစ်ခု တစ်ပြိုင်နက် write မလုပ်စေရန်ဖြစ်သည်။ Users မသုံးနေချိန် upgrade လုပ်ပါ။
၈။ Deploy:

```bash
npx firebase-tools deploy --only functions,firestore,hosting
```

၉။ https://fvm-26.web.app/admin.html တွင် owner Gmail ဖြင့်ဝင်ပါ။ Approval mode ထားပြီး အခြား Gmail တစ်ခု Pending → Approve → Vault save/load ကိုအရင်စမ်းပါ။
၁၀။ အများသုံးမဖွင့်မီ README.my.md ထဲ OAuth Production၊ App Check၊ Operator name/support email၊ email setup နှင့် live testing အပိုင်းတွေကို ပြီးစီးပါ။

Setup အပြည့်အစုံသည် README.my.md ထဲမှာ ရှိပါသည်။ Backend deploy/live devices/၂၀၀-user load test ကို သင့် project မှာ မလုပ်ရသေးပါ။
