import express from 'express';
import {initializeApp} from 'firebase-admin/app';
import {getAuth} from 'firebase-admin/auth';
import {getFirestore} from 'firebase-admin/firestore';
import {onRequest} from 'firebase-functions/v2/https';
import {onSchedule} from 'firebase-functions/v2/scheduler';
import {defineString,defineBoolean,defineSecret,defineInt} from 'firebase-functions/params';
import {getAppCheck} from 'firebase-admin/app-check';
import {controls} from './control.js';
import {driveStore} from './drive.js';
import {adminEmails,check,POLICY_VERSION} from './policy.js';
initializeApp();
const db=getFirestore();
const ADMIN_EMAILS=defineString('ADMIN_EMAILS',{description:'Comma-separated owner/admin verified Google emails; never put this in public config'});
const SITE_URL=defineString('SITE_URL',{description:'Canonical HTTPS website URL, e.g. https://fvm-26.web.app'});
const REGISTRATION_MODE=defineString('REGISTRATION_MODE',{default:'approval'});
const MAX_REGISTRATIONS=defineInt('MAX_REGISTRATIONS',{default:500});
const APP_CHECK_REQUIRED=defineBoolean('APP_CHECK_REQUIRED',{default:false});
const EMAIL_ENABLED=defineBoolean('EMAIL_ENABLED',{default:false});
const EMAIL_FROM=defineString('EMAIL_FROM',{default:'Family Vault <noreply@example.com>'});
const MAIL_API_KEY=defineSecret('MAIL_API_KEY');
const app=express();app.disable('x-powered-by');
app.use((req,res,next)=>{res.set('Cache-Control','no-store');if(req.rawBody?.length>4500000)return res.status(413).json({ok:false,error:'Request exceeds size limit'});next();});
app.use(express.text({type:['text/plain','application/json'],limit:'4500kb'}));
app.get(['/api/health','/health'],(req,res)=>res.json({ok:true,version:3,policyVersion:POLICY_VERSION}));
app.post(['/api','/'],async(req,res)=>{
  try {
    const input=typeof req.body==='string'?JSON.parse(req.body):req.body;
    check(input&&typeof input.action==='string','Invalid request');
    const bearer=req.get('Authorization');const token=bearer?.startsWith('Bearer ')?bearer.slice(7):input.idToken;
    check(typeof token==='string'&&token.length<10000,'Firebase login required',401);
    let id;try{id=await getAuth().verifyIdToken(token,true);}catch{check(false,'Firebase login expired or invalid',401);}
    check(id.email_verified===true&&id.firebase?.sign_in_provider==='google.com'&&/^[A-Za-z0-9_-]{1,128}$/.test(id.uid),'Verified Google login required',403);
    // Normalise server-issued claims only, never trust client-supplied role/email/UID.
    id={...id,emailVerified:id.email_verified};
    if(APP_CHECK_REQUIRED.value()) {
      try{await getAppCheck().verifyToken(req.get('X-Firebase-AppCheck')||'');}catch{check(false,'App verification failed. Reload or contact admin.',403);}
    }
    const adminList=adminEmails(ADMIN_EMAILS.value());check(adminList.length>0,'Owner setup incomplete',503);
    const ctl=controls(db,adminList,REGISTRATION_MODE.value(),SITE_URL.value(),MAX_REGISTRATIONS.value());await ctl.rateLimit(id);
    let result;
    if(input.action.startsWith('admin'))result=await ctl.admin(id,input);
    else if(input.action==='register')result=await ctl.registration(id,input);
    else if(input.action==='membership')result=await ctl.status(id);
    else if(input.action==='closeAccount')result=await ctl.closeAccount(id);
    else {await ctl.membership(id);result=await driveStore(db).execute(id,input);}
    if(input.action==='save')result.emailDeliveryEnabled=EMAIL_ENABLED.value();
    res.json(result);
  }catch(error){const status=error.status||(error instanceof SyntaxError?400:500);res.status(status).json({ok:false,error:status>=500?'Server connection failed. Retry; if already saved, Refresh before editing again.':error.message});}
});
app.use((error,req,res,next)=>res.status(error.status||400).json({ok:false,error:'Request body invalid or too large'}));
export const api=onRequest({region:'us-central1',timeoutSeconds:55,memory:'512MiB',maxInstances:4,concurrency:20},app);
// Optional Resend delivery. No Google tokens are stored or needed for scheduled reminders.
export const dailyReminders=onSchedule({schedule:'0 8 * * *',timeZone:'America/New_York',region:'us-central1',timeoutSeconds:540,maxInstances:1,secrets:[MAIL_API_KEY]},async()=>{
  if(!EMAIL_ENABLED.value())return;
  const now=new Date(),today=new Intl.DateTimeFormat('en-CA',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
  const end=new Date(today+'T00:00:00Z');end.setUTCDate(end.getUTCDate()+7);const endDate=end.toISOString().slice(0,10);
  let cursor=null;
  do {
    let q=db.collection('reminders').orderBy('__name__').limit(100);if(cursor)q=q.startAfter(cursor);
    const batch=await q.get();
    for(const doc of batch.docs) {
      const reminder=doc.data(),member=(await db.collection('members').doc(doc.id).get()).data();
      if(!member||member.status!=='active'||member.email!==reminder.email||reminder.sentDay===today)continue;
      const dates=reminder.dates||[],overdue=dates.filter(d=>d.date<today).length,upcoming=dates.filter(d=>d.date>=today&&d.date<=endDate).length;
      if(!overdue&&!upcoming)continue;
      // Confirm still opted in/active immediately before delivery.
      const latest=(await doc.ref.get()).data(),current=(await db.collection('members').doc(doc.id).get()).data();
      if(!latest||current?.status!=='active')continue;
      try {
        await new Promise(resolve=>setTimeout(resolve,550));
        const response=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+MAIL_API_KEY.value(),'Content-Type':'application/json','Idempotency-Key':'vault-'+doc.id+'-'+today},body:JSON.stringify({from:EMAIL_FROM.value(),to:reminder.email,subject:'Family Vault — private reminder',text:`သင့် Vault တွင် overdue ${overdue} ခု၊ နောက် ၇ ရက်အတွင်း စစ်ဆေးရန် ${upcoming} ခုရှိပါသည်။\n${SITE_URL.value()}\nEmail reminders ကို Vault Settings တွင် ပိတ်နိုင်ပါသည်။`}),signal:AbortSignal.timeout(15000)});
        if(response.ok)await doc.ref.update({sentDay:today});
      }catch{/* Retry next scheduled run; do not log identities, tokens or reminders. */}
    }
    cursor=batch.size===100?batch.docs.at(-1).id:null;
  }while(cursor);
});
