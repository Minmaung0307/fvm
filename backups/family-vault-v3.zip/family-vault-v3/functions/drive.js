import {randomBytes,randomUUID} from 'node:crypto';
import {check,owned,validateEnvelope,validateDates,matchGoogle} from './policy.js';
const DRIVE='https://www.googleapis.com/drive/v3/files',SHEETS='https://sheets.googleapis.com/v4/spreadsheets/';
export function driveStore(db,fetcher=fetch) {
  async function call(ctx,url,method='GET',body,type='application/json') {
    const result=await fetcher(url,{method,headers:{Authorization:'Bearer '+ctx.token,...(body===undefined?{}:{'Content-Type':type})},body:body===undefined?undefined:typeof body==='string'?body:JSON.stringify(body),signal:ctx.signal});
    check(result.status!==401,'Google Drive permission expired. Sign out and reconnect.',401);
    check(result.status!==403,'Google access denied. Enable Drive/Sheets APIs and reconnect permission.',403);
    check(result.status!==404,'Drive file missing. Restore it from Trash; do not reset the vault.',404);
    check(result.ok,'Google API request failed. Retry or check API quota.',502);
    const text=await result.text();return text?JSON.parse(text):{};
  }
  async function context(id,input){check(typeof input.googleToken==='string'&&input.googleToken.length>10&&input.googleToken.length<10000,'Drive login required',401);const ctx={uid:id.uid,email:id.email,token:input.googleToken,signal:AbortSignal.timeout(45000)};matchGoogle(id,await call(ctx,'https://www.googleapis.com/oauth2/v3/userinfo'));return ctx;}
  const tags=(ctx,role)=>({app:'family-vault-v2',uid:ctx.uid,role});
  async function metadata(ctx,fileId,role,parent){check(typeof fileId==='string'&&/^[A-Za-z0-9_-]{5,200}$/.test(fileId),'Invalid file ID');return owned(await call(ctx,DRIVE+'/'+fileId+'?fields=id,mimeType,ownedByMe,parents,appProperties,trashed'),ctx.uid,role,parent);}
  async function find(ctx,q,role,parent){let files=[],page;do {const result=await call(ctx,DRIVE+'?q='+encodeURIComponent(q)+'&fields=files(id,mimeType,ownedByMe,parents,appProperties,trashed),nextPageToken&pageSize=100'+(page?'&pageToken='+encodeURIComponent(page):''));files.push(...(result.files||[]));page=result.nextPageToken;check(files.length<=1,'Multiple vault folders/databases found. Back up before resolving duplicates.');}while(page);return files.length?owned(files[0],ctx.uid,role,parent):null;}
  async function read(ctx,storage){
    const rows=(await call(ctx,SHEETS+storage.sheetId+'/values/Vault!A1:D202')).values||[];
    check(rows.length>=2&&rows[0][0]==='revision'&&rows[1][1],'Database metadata damaged. Restore a backup.');
    const [revision,salt,countText]=rows[1],count=Number(countText),rev=Number(revision);
    check(Number.isSafeInteger(rev)&&rev>=0&&Number.isInteger(count)&&count>=0&&count<=100,'Invalid database metadata');
    let box=null;if(count){const chunks=rows.slice(2,2+count);check(chunks.length===count&&chunks.every(r=>typeof r[0]==='string'),'Database chunks missing');box=validateEnvelope(JSON.parse(chunks.map(r=>r[0]).join('')));}
    return {ok:true,revision:rev,salt,box,folderId:storage.folderId,sheetId:storage.sheetId};
  }
  async function provision(ctx) {
    const ref=db.collection('storage').doc(ctx.uid),cached=(await ref.get()).data();
    if(cached){await metadata(ctx,cached.folderId,'folder');await metadata(ctx,cached.sheetId,'database',cached.folderId);return {storage:cached,state:null};}
    const marker="trashed=false and appProperties has { key='app' and value='family-vault-v2' } and appProperties has { key='uid' and value='"+ctx.uid+"' }";
    let folder=await find(ctx,marker+" and appProperties has { key='role' and value='folder' }",'folder');
    if(!folder)folder=await call(ctx,DRIVE+'?fields=id','POST',{name:'Family Vault — Private',mimeType:'application/vnd.google-apps.folder',appProperties:tags(ctx,'folder')});
    let sheet=await find(ctx,marker+" and '"+folder.id+"' in parents and appProperties has { key='role' and value='database' }",'database',folder.id);
    if(!sheet)sheet=await call(ctx,DRIVE+'?fields=id','POST',{name:'Family Vault — Encrypted Database',mimeType:'application/vnd.google-apps.spreadsheet',parents:[folder.id],appProperties:tags(ctx,'database')});
    const sheets=(await call(ctx,SHEETS+sheet.id+'?fields=sheets.properties')).sheets||[];
    const tab=sheets.find(s=>s.properties.title==='Vault')||sheets[0];check(tab,'Database sheet missing');
    if(tab.properties.title!=='Vault')await call(ctx,SHEETS+sheet.id+':batchUpdate','POST',{requests:[{updateSheetProperties:{properties:{sheetId:tab.properties.sheetId,title:'Vault'},fields:'title'}}]});
    const storage={folderId:folder.id,sheetId:sheet.id,gridId:tab.properties.sheetId};
    const rows=(await call(ctx,SHEETS+sheet.id+'/values/Vault!A1:D202')).values||[];
    if(!rows.length)await call(ctx,SHEETS+sheet.id+'/values/Vault!A1:D2?valueInputOption=RAW','PUT',{values:[['revision','salt','chunkCount','updatedAt'],['0',randomBytes(32).toString('base64'),'0',new Date().toISOString()]]});
    const state=await read(ctx,storage);await ref.set(storage);return {storage,state};
  }
  async function lease(uid,fn) {
    const ref=db.collection('leases').doc(uid),token=randomUUID(),now=Date.now();
    await db.runTransaction(async tx=>{const old=(await tx.get(ref)).data();check(!old||old.until<now,'အခြား device တွင် save လုပ်နေပါသည်။ ခဏနားပြီး ပြန်လုပ်ပါ။',409);tx.set(ref,{token,until:now+90000});});
    try{return await fn();}finally{await db.runTransaction(async tx=>{const old=(await tx.get(ref)).data();if(old?.token===token)tx.delete(ref);}).catch(()=>{});}
  }
  async function execute(id,input) {
    check(['load','save','uploadDocument','downloadDocument','trashDocument'].includes(input.action),'Unknown action');
    if(input.action==='save'){validateEnvelope(input.box);validateDates(input.reminders);check(Number.isSafeInteger(input.revision)&&input.revision>=0,'Invalid revision');}
    if(input.action==='uploadDocument')validateEnvelope(input.box,4200000);
    const ctx=await context(id,input);
    return lease(id.uid,async()=>{
      const {storage,state}=await provision(ctx);
      if(input.action==='load')return state||read(ctx,storage);
      if(input.action==='save') {
        const previous=state||await read(ctx,storage);check(input.revision===previous.revision,'အခြား device မှ ပြင်ထားပါသည်။ Refresh လုပ်ပြီး ပြန်ပြင်ပါ။',409);
        const box=validateEnvelope(input.box),dates=validateDates(input.reminders),chunks=JSON.stringify(box).match(/.{1,30000}/g),revision=previous.revision+1;
        const rows=[[String(revision),previous.salt,String(chunks.length),new Date().toISOString()]].concat(chunks.map(c=>[c]));
        await call(ctx,SHEETS+storage.sheetId+':batchUpdate','POST',{requests:[{updateCells:{range:{sheetId:storage.gridId,startRowIndex:1,endRowIndex:202,startColumnIndex:0,endColumnIndex:4},rows:rows.map(row=>({values:row.map(v=>({userEnteredValue:{stringValue:v}}))})),fields:'userEnteredValue'}}]});
        let reminderConfigured=true;
        try {const ref=db.collection('reminders').doc(id.uid);if(input.emailReminders===true)await ref.set({email:id.email,dates,updatedAt:Date.now()},{merge:true});else await ref.delete();}catch{reminderConfigured=false;}
        return {ok:true,revision,reminderConfigured};
      }
      if(input.action==='uploadDocument') {
        const box=validateEnvelope(input.box,4200000),boundary='fv_'+randomUUID().replaceAll('-','');
        const info={name:randomUUID()+'.fvdoc',mimeType:'application/json',parents:[storage.folderId],appProperties:tags(ctx,'document')};
        const body='--'+boundary+'\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n'+JSON.stringify(info)+'\r\n--'+boundary+'\r\nContent-Type: application/json\r\n\r\n'+JSON.stringify(box)+'\r\n--'+boundary+'--';
        const result=await call(ctx,'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id','POST',body,'multipart/related; boundary='+boundary);
        return {ok:true,fileId:result.id};
      }
      await metadata(ctx,input.fileId,'document',storage.folderId);
      if(input.action==='downloadDocument')return {ok:true,box:validateEnvelope(await call(ctx,DRIVE+'/'+input.fileId+'?alt=media'),4200000)};
      await call(ctx,DRIVE+'/'+input.fileId,'PATCH',{trashed:true});return {ok:true};
    });
  }
  return {execute,read,lease};
}
