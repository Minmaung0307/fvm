import {createHash,randomBytes} from 'node:crypto';
export const POLICY_VERSION='2026-09-v1';
export class Failure extends Error { constructor(message,status=400){super(message);this.status=status;} }
export function check(condition,message,status=400){if(!condition)throw new Failure(message,status);}
export const email=value=>String(value||'').trim().toLowerCase();
export function adminEmails(value){return String(value||'').split(',').map(email).filter(Boolean);}
export function isAdministrator(identity,list){return identity.emailVerified===true&&list.includes(email(identity.email));}
export function registrationState(previous,mode,inviteValid,isAdmin){
  if(isAdmin)return 'active';
  if(previous){if(previous==='pending'&&inviteValid)return 'active';return previous;}
  return inviteValid||mode==='open'?'active':'pending';
}
export function validateMode(mode){check(['approval','invite','open'].includes(mode),'Invalid registration mode');return mode;}
export function validateEnvelope(box,max=1000000){
  check(box&&box.v===1&&typeof box.iv==='string'&&/^[A-Za-z0-9+/]{16}$/.test(box.iv)&&typeof box.ciphertext==='string'&&/^[A-Za-z0-9+/]+={0,2}$/.test(box.ciphertext)&&box.ciphertext.length>=24&&box.ciphertext.length<=max,'Invalid encrypted data or size limit exceeded');
  return {v:1,iv:box.iv,ciphertext:box.ciphertext};
}
export function validateDates(dates){check(Array.isArray(dates)&&dates.length<=1000,'Invalid reminders');return dates.map(d=>{check(d&&['due','renewal','expiry','document'].includes(d.kind)&&/^\d{4}-\d{2}-\d{2}$/.test(d.date)&&!Number.isNaN(Date.parse(d.date+'T00:00:00Z')),'Invalid reminder date');return {kind:d.kind,date:d.date};});}
export function owned(file,uid,role,parent){check(file&&file.ownedByMe===true&&!file.trashed&&file.appProperties?.uid===uid&&file.appProperties?.app==='family-vault-v2'&&file.appProperties?.role===role&&(!parent||file.parents?.includes(parent)),'File does not belong to your private vault',403);return file;}
export function matchGoogle(identity,google){check(google.email_verified===true&&email(google.email)===email(identity.email)&&identity.firebase?.identities?.['google.com']?.includes(google.sub),'Firebase login and Drive account must match',403);}
export function tokenHash(token){check(typeof token==='string'&&/^[A-Za-z0-9_-]{43}$/.test(token),'Invalid invitation');return createHash('sha256').update(token).digest('hex');}
export function newInvitation(){const token=randomBytes(32).toString('base64url');return {token,hash:tokenHash(token)};}
export function invitationValid(invite,identity,now=Date.now()){return !!invite&&!invite.revoked&&!invite.usedBy&&invite.expiresAt>now&&email(invite.email)===email(identity.email);}
export function publicMember(uid,value,isAdmin=false){return {uid,email:value.email,name:value.name,status:isAdmin?'active':value.status,createdAt:value.createdAt,lastLoginAt:value.lastLoginAt,isAdmin};}
