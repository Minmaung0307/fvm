import test from 'node:test';import assert from 'node:assert/strict';
import {driveStore} from '../drive.js';import {fakeFirestore} from './fake-firestore.js';
const identity={uid:'alice',email:'alice@gmail.com',firebase:{identities:{'google.com':['google-alice']}}};
const box={v:1,iv:'AAAAAAAAAAAAAAAA',ciphertext:'A'.repeat(24)};
function setup() {
  const mock=fakeFirestore({'storage/alice':{folderId:'folderAlice',sheetId:'sheetAlice',gridId:0}});
  let rows=[['revision','salt','chunkCount','updatedAt'],['0','salt','0','now']],writes=0;
  const fetcher=async(url,options)=>{
    assert.equal(options.headers.Authorization,'Bearer google-token-alice');
    let payload;
    if(url.includes('userinfo'))payload={email:identity.email,email_verified:true,sub:'google-alice'};
    else if(url.includes('/drive/v3/files/')){const id=url.split('/files/')[1].split('?')[0];payload={id,ownedByMe:true,parents:['folderAlice'],appProperties:{app:'family-vault-v2',uid:id==='docBob'?'bob':'alice',role:id==='folderAlice'?'folder':id==='sheetAlice'?'database':'document'}};}
    else if(url.includes('/values/'))payload={values:structuredClone(rows)};
    else if(url.endsWith(':batchUpdate')){const body=JSON.parse(options.body);rows=[rows[0],...body.requests[0].updateCells.rows.map(r=>r.values.map(v=>v.userEnteredValue.stringValue))];writes++;payload={};}
    else throw Error('Unexpected URL '+url);
    return {ok:true,status:200,text:async()=>JSON.stringify(payload)};
  };
  return {...mock,store:driveStore(mock.db,fetcher),writes:()=>writes};
}
test('save CAS updates Sheets atomically, stale revision rejected, reminder contains no token',async()=>{const {store,data,writes}=setup();const input={action:'save',googleToken:'google-token-alice',box,revision:0,reminders:[{kind:'due',date:'2026-10-01'}],emailReminders:true};assert.equal((await store.execute(identity,input)).revision,1);assert.equal(writes(),1);assert.deepEqual((await store.execute(identity,{action:'load',googleToken:input.googleToken})).box,box);await assert.rejects(store.execute(identity,input),/Refresh/);assert.equal(writes(),1);assert(!JSON.stringify(data.get('reminders/alice')).includes(input.googleToken));assert(!data.has('leases/alice'));});
test('guessed other-user Drive document is rejected before download',async()=>{const {store}=setup();await assert.rejects(store.execute(identity,{action:'downloadDocument',googleToken:'google-token-alice',fileId:'docBob'}),/belong/);});
test('per-user lease prevents concurrent same-user writes but lets other users work',async()=>{const {store}=setup();let finish,started;const ready=new Promise(resolve=>started=resolve);const first=store.lease('alice',async()=>{started();await new Promise(resolve=>finish=resolve);});await ready;await assert.rejects(store.lease('alice',async()=>{}),/device/);let other=false;await store.lease('bob',async()=>{other=true;});assert(other);finish();await first;await store.lease('alice',async()=>{});});
