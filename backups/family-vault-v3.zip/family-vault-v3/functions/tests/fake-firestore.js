// Transaction mock enforces Firestore's read-before-write rule and serialises commits.
export function fakeFirestore(seed={}) {
  const data=new Map(Object.entries(seed).map(([k,v])=>[k,structuredClone(v)]));let sequence=0,tail=Promise.resolve();
  const snapshot=ref=>({id:ref.id,ref,exists:data.has(ref.path),data:()=>structuredClone(data.get(ref.path))});
  const ref=path=>({path,id:path.split('/').at(-1),get:async()=>snapshot(ref(path)),set:async(value,options)=>data.set(path,options?.merge?{...data.get(path),...structuredClone(value)}:structuredClone(value)),update:async value=>{if(!data.has(path))throw Error('Not found');data.set(path,{...data.get(path),...structuredClone(value)});},delete:async()=>data.delete(path)});
  function collection(path){
    let filters=[],orders=[],cap=Infinity,after;
    const query={doc:id=>ref(path+'/'+(id||'auto'+ ++sequence)),where:(field,op,value)=>{filters.push([field,op,value]);return query;},orderBy:(field,direction='asc')=>{orders.push([field,direction]);return query;},limit:n=>{cap=n;return query;},startAfter:(...values)=>{after=values;return query;},get:async()=>{
      let docs=[...data.keys()].filter(k=>k.startsWith(path+'/')&&k.split('/').length===path.split('/').length+1).map(k=>snapshot(ref(k)));
      const val=(d,field)=>field==='__name__'?d.id:d.data()[field];
      docs=docs.filter(d=>filters.every(([field,op,value])=>op==='=='?val(d,field)===value:op==='<'?val(d,field)<value:false));
      docs.sort((a,b)=>{for(const [field,direction]of orders){const x=val(a,field),y=val(b,field);if(x!==y)return (x<y?-1:1)*(direction==='desc'?-1:1);}return 0;});
      if(after)docs=docs.filter(d=>{for(let i=0;i<orders.length;i++){const [field,direction]=orders[i],v=val(d,field);if(v!==after[i])return direction==='desc'?v<after[i]:v>after[i];}return false;});
      docs=docs.slice(0,cap);return {docs,size:docs.length};
    }};return query;
  }
  const db={collection,doc:ref,runTransaction:fn=>{const job=tail.then(async()=>{const pending=[];let written=false;const tx={get:async r=>{if(written)throw Error('Firestore reads must precede writes');return snapshot(r);},set:(r,v,o)=>{written=true;pending.push(()=>r.set(v,o));},update:(r,v)=>{written=true;pending.push(()=>r.update(v));},delete:r=>{written=true;pending.push(()=>r.delete());}};const result=await fn(tx);for(const write of pending)await write();return result;});tail=job.catch(()=>{});return job;}};
  return {db,data};
}
