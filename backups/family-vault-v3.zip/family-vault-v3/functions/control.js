import {check,email,isAdministrator,registrationState,validateMode,newInvitation,tokenHash,invitationValid,publicMember,POLICY_VERSION} from './policy.js';
export function controls(db,admins,initialMode='approval',siteURL='',maxRegistrations=500) {
  const memberRef=uid=>db.collection('members').doc(uid);
  const settingsRef=db.doc('system/settings');
  const audit=(tx,actor,action,target,detail={})=>tx.set(db.collection('audit').doc(),{actor:actor.uid,action,target,detail,at:Date.now()});
  const administrator=id=>{check(isAdministrator(id,admins),'Admin access required',403);};
  async function rateLimit(id) {
    const ref=db.collection('limits').doc(id.uid),now=Date.now(),window=Math.floor(now/60000);
    await db.runTransaction(async tx=>{const old=(await tx.get(ref)).data();const count=old?.window===window?old.count+1:1;check(count<=60,'Requests များနေပါသည်။ တစ်မိနစ်နားပြီး ပြန်လုပ်ပါ။',429);tx.set(ref,{window,count});});
  }
  async function registration(id,input) {
    check(input.accepted===true&&input.policyVersion===POLICY_VERSION,'Privacy/Terms ကို သဘောတူပါ။');
    const isAdmin=isAdministrator(id,admins),ref=memberRef(id.uid),inviteRef=input.invite?db.collection('invites').doc(tokenHash(input.invite)):null;
    return db.runTransaction(async tx=>{
      const member=(await tx.get(ref)).data(),settings=(await tx.get(settingsRef)).data()||{};
      const invite=inviteRef?(await tx.get(inviteRef)).data():null;
      const valid=invitationValid(invite,id);
      if(inviteRef)check(valid,'Invite သည် ဤ Gmail အတွက် မဟုတ်ပါ၊ သို့မဟုတ် သက်တမ်းကုန်/အသုံးပြုပြီး ဖြစ်ပါသည်။');
      const metricsRef=db.doc('system/registrationMetrics');const metrics=!member?(await tx.get(metricsRef)).data()||{}:null;
      if(!member)check(isAdmin||(metrics.total||0)<maxRegistrations,'စာရင်းသွင်းသူအရေအတွက် ပြည့်နေပါသည်။ Admin ထံ ဆက်သွယ်ပါ။',403);
      const mode=validateMode(settings.registrationMode||initialMode);
      check(member||isAdmin||mode!=='invite'||valid,'ဤ app ကို invite ဖြင့်သာ စာရင်းသွင်းနိုင်ပါသည်။',403);
      const status=registrationState(member?.status,mode,valid,isAdmin),now=Date.now();
      const value={email:email(id.email),name:String(id.name||'').slice(0,100),status,createdAt:member?.createdAt||now,lastLoginAt:now,consentVersion:POLICY_VERSION,consentAt:member?.consentAt||now};
      tx.set(ref,value,{merge:true});
      if(!member)tx.set(metricsRef,{total:(metrics.total||0)+1});
      if(valid&&['active','pending'].includes(status)){tx.update(inviteRef,{usedBy:id.uid,usedAt:now});audit(tx,id,'invite.redeem',id.uid);}
      if(!member)audit(tx,id,'member.register',id.uid,{status});
      return {ok:true,...publicMember(id.uid,value,isAdmin),registrationMode:mode};
    });
  }
  async function membership(id) {
    const value=(await memberRef(id.uid).get()).data();
    check(value,'စာရင်းသွင်းရန် လိုအပ်ပါသည်။',403);
    check(isAdministrator(id,admins)||value.status==='active',value.status==='pending'?'Admin ခွင့်ပြုချက်ကို စောင့်နေပါသည်။':value.status==='closed'?'သင့် account ကို ပိတ်ထားပါသည်။':'သင့်အသုံးပြုခွင့်ကို ယာယီရပ်ထားပါသည်။',403);
    return value;
  }
  async function status(id) {const value=(await memberRef(id.uid).get()).data();check(value,'Registration required',403);return {ok:true,...publicMember(id.uid,value,isAdministrator(id,admins))};}
  async function closeAccount(id) {
    check(!isAdministrator(id,admins),'Owner account ကို ဒီနေရာက မပိတ်နိုင်ပါ။');
    await db.runTransaction(async tx=>{const ref=memberRef(id.uid);check((await tx.get(ref)).exists,'Account missing');tx.update(ref,{status:'closed',closedAt:Date.now()});tx.delete(db.collection('reminders').doc(id.uid));audit(tx,id,'member.close',id.uid);});
    return {ok:true};
  }
  async function admin(id,input) {
    administrator(id);
    switch(input.action) {
      case 'adminSettings': {
        const value=(await settingsRef.get()).data()||{};
        const metrics=(await db.doc('system/registrationMetrics').get()).data()||{};
        return {ok:true,registrationMode:value.registrationMode||initialMode,policyVersion:POLICY_VERSION,totalRegistrations:metrics.total||0,maxRegistrations};
      }
      case 'adminSetMode': {
        const mode=validateMode(input.mode);
        await db.runTransaction(async tx=>{await tx.get(settingsRef);tx.set(settingsRef,{registrationMode:mode,updatedAt:Date.now()},{merge:true});audit(tx,id,'settings.mode','system',{mode});});return {ok:true};
      }
      case 'adminUsers': {
        let q=db.collection('members').orderBy('__name__').limit(50);
        if(input.cursor){check(typeof input.cursor==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(input.cursor),'Invalid cursor');q=q.startAfter(input.cursor);}
        const result=await q.get(),users=result.docs.map(d=>publicMember(d.id,d.data(),admins.includes(d.data().email)));
        return {ok:true,users,nextCursor:users.length===50?users.at(-1).uid:null};
      }
      case 'adminFindUser': {
        const address=email(input.email);check(address&&address.length<255,'Email required');const result=await db.collection('members').where('email','==',address).limit(10).get();return {ok:true,users:result.docs.map(d=>publicMember(d.id,d.data(),admins.includes(d.data().email)))};
      }
      case 'adminBulkStatus': {
        check(Array.isArray(input.uids)&&input.uids.length>=1&&input.uids.length<=25&&new Set(input.uids).size===input.uids.length,'Select 1–25 unique users');
        check(['active','suspended'].includes(input.status),'Invalid bulk status');
        check(input.uids.every(uid=>typeof uid==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(uid)),'Invalid user ID');
        await db.runTransaction(async tx=>{
          const rows=[];
          for(const uid of input.uids){const ref=memberRef(uid),old=(await tx.get(ref)).data();check(old,'User missing',404);check(!admins.includes(old.email)&&uid!==id.uid,'Owner/admin status မပြောင်းနိုင်ပါ။',403);check(old.status!=='closed','Closed account ပါနေပါသည်။');rows.push({uid,ref,old});}
          for(const {uid,ref,old}of rows){tx.update(ref,{status:input.status,updatedAt:Date.now()});if(input.status!=='active')tx.delete(db.collection('reminders').doc(uid));audit(tx,id,'member.status',uid,{from:old.status,to:input.status,bulk:true});}
        });return {ok:true,count:input.uids.length};
      }
      case 'adminSetStatus': {
        check(typeof input.uid==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(input.uid),'Invalid user');
        check(['active','suspended','pending'].includes(input.status),'Invalid status');
        const ref=memberRef(input.uid);
        await db.runTransaction(async tx=>{const old=(await tx.get(ref)).data();check(old,'User missing',404);check(!admins.includes(old.email)&&input.uid!==id.uid,'Owner/admin status မပြောင်းနိုင်ပါ။',403);check(old.status!=='closed','User ကိုယ်တိုင်ပိတ်ထားသော account ကို ပြန်မဖွင့်နိုင်ပါ။');tx.update(ref,{status:input.status,updatedAt:Date.now()});if(input.status!=='active')tx.delete(db.collection('reminders').doc(input.uid));audit(tx,id,'member.status',input.uid,{from:old.status,to:input.status});});return {ok:true};
      }
      case 'adminInvite': {
        const address=email(input.email);check(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(address)&&address.length<255,'Valid Gmail/email လိုပါသည်။');
        const days=Number(input.days||7);check(Number.isInteger(days)&&days>=1&&days<=30,'Expiry must be 1–30 days');
        const url=new URL(siteURL);check(url.protocol==='https:','SITE_URL must use HTTPS');
        const {token,hash}=newInvitation(),value={email:address,createdAt:Date.now(),expiresAt:Date.now()+days*86400000,revoked:false,usedBy:null};
        await db.runTransaction(async tx=>{tx.set(db.collection('invites').doc(hash),value);audit(tx,id,'invite.create',address);});
        url.hash='invite='+token;
        return {ok:true,url:url.href,id:hash,expiresAt:value.expiresAt};
      }
      case 'adminInvites': {
        let q=db.collection('invites').orderBy('__name__').limit(50);if(input.cursor){check(/^[a-f0-9]{64}$/.test(input.cursor),'Invalid cursor');q=q.startAfter(input.cursor);}
        const result=await q.get();return {ok:true,invites:result.docs.map(d=>({id:d.id,...d.data()})),nextCursor:result.size===50?result.docs.at(-1).id:null};
      }
      case 'adminRevokeInvite': {
        check(/^[a-f0-9]{64}$/.test(input.id),'Invalid invite ID');const ref=db.collection('invites').doc(input.id);
        await db.runTransaction(async tx=>{check((await tx.get(ref)).exists,'Invite missing',404);tx.update(ref,{revoked:true});audit(tx,id,'invite.revoke',input.id);});return {ok:true};
      }
      case 'adminAudit': {
        let q=db.collection('audit').orderBy('at','desc').orderBy('__name__','desc').limit(50);
        if(input.cursor){check(Number.isFinite(input.cursor.at)&&typeof input.cursor.id==='string','Invalid cursor');q=q.startAfter(input.cursor.at,input.cursor.id);}
        const result=await q.get();return {ok:true,events:result.docs.map(d=>({id:d.id,...d.data()})),nextCursor:result.size===50?{at:result.docs.at(-1).data().at,id:result.docs.at(-1).id}:null};
      }
      default: throw Error('Unknown admin action');
    }
  }
  return {registration,membership,status,closeAccount,admin,rateLimit};
}
