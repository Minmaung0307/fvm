import {initializeAppCheck,ReCaptchaV3Provider,getToken} from 'https://www.gstatic.com/firebasejs/12.2.1/firebase-app-check.js';
import {config} from './config.js';
let appCheck;
export function enableAppCheck(app){if(config.appCheckSiteKey)appCheck=initializeAppCheck(app,{provider:new ReCaptchaV3Provider(config.appCheckSiteKey),isTokenAutoRefreshEnabled:true});}
export async function backendRequest(user,action,extra={}) {
  if(!user)throw Error('Google login လိုပါသည်။');
  const headers={'Content-Type':'application/json',Authorization:'Bearer '+await user.getIdToken()};
  if(appCheck)headers['X-Firebase-AppCheck']=(await getToken(appCheck,false)).token;
  const response=await fetch(config.apiUrl,{method:'POST',headers,body:JSON.stringify({action,...extra}),cache:'no-store'});
  let result;try{result=await response.json();}catch{throw Error('Backend setup မပြီးသေးပါ သို့မဟုတ် server ချိတ်ဆက်မရပါ။');}
  if(!response.ok||!result.ok){const error=new Error(result.error||'Request failed');error.status=response.status;throw error;}return result;
}
