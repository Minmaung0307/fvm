export const config = {
  firebase: {
    apiKey:'AIzaSyCzBnMGTRxQFY0-NtcW4jatiM5oupLhyo0',
    authDomain:'fvm-26.firebaseapp.com',
    projectId:'fvm-26',
    appId:'1:664171086120:web:4cefb5089f956d202c101d'
  },
  apiUrl:'/api',
  currency:'USD', idleMinutes:5, maxDocumentBytes:3*1024*1024,
  appCheckSiteKey:''
};
